
public class PT_P1_1 {
	PT_P1_1(){
		
		long l=(long)Math.pow(3, 22);
		int i = (int)l;
		
		System.out.println(l);
		System.out.println(i);
	}
	public static void main(String[] args) {
		PT_P1_1 pt1_1=new PT_P1_1();
	}
}

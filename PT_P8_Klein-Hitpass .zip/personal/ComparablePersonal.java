package personal;

public interface ComparablePersonal {
	int comparePersonal(Personal p);
}

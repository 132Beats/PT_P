package personal;

public interface ComparablePersonal {
	int test=5;
	int comparePersonal(Personal p);
}
